input('Eric')

print("Hello Eric and welcome to CS Online!")